/*
 * nwd.cpp

 */


#include <iostream>

using namespace std;

    int nwd int a int b;
        if 

int main(int argc, char **argv)
{
	
	return 0;
}

