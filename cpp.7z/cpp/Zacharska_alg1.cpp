/*
 * zlozonosc_alg1.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	int a;
    cout << "Podaj a:"<< endl;
    cin >> a;
    for ( a = 0; a < 100; a+=2){
        cout <<a<< endl;
        }
   
	return 0;
}

