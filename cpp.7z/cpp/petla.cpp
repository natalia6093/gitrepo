/*
 * petla.cpp
 
 */
#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int i;
    
    
    return 0;
}

